'''
Новая таблица Excel
Создайте новую таблицу Excel, по умолчанию это таблица с именем Sheet, а именно:
from openpyxl import Workbook
wb = Workbook () # Создать файловый объект
 ws = wb.active # Получить лист по умолчанию
wb.save("sample.xlsx")
'''


'''
Открыть существующую таблицу Excel
from openpyxl import Workbook, load_workbook
wb = load_workbook('sample.xlsx')
'''

'''
Создать / получить лист
Используйте метод Workbook.create_sheet () для создания нового листа.
Первый параметр - это имя листа.
Если он не заполнен, по умолчанию он будет называться Sheet1 Sheet2 Sheet3;
второй параметр - это позиция для вставки таблицы Sheet, с 0 в качестве первой позиции,
если она не заполнена, она будет В конце. следующее:
ws1 = wb.create_sheet ("Mysheet") # По умолчанию вставляется в конец
ws2 = wb.create_sheet ("Mysheet", 0) # Вставить в первую позицию
 
Вы также можете изменить имя листа в любое время позже, следующим образом:
ws.title = "New Title"
 
Измените цвет метки листа следующим образом:
ws.sheet_properties.tabColor = "1072BA"
'''

'''
Операционная ячейка

Получите ячейку с листа или назначьте ячейку напрямую, как показано ниже:

cell = ws ['A4'] # Получить ячейку в строке 4 и столбце A
 ws ['A4'] = 4 # Присвойте значение 4 ячейке в строке 4 и столбце A
 ws.cell (row = 4, column = 2, value = 10) # Присвойте значение 10 ячейке в строке 4 и столбце 2
 ws.cell (4, 2, 10) # То же, что и выше
 
Получите клетки в этом районе следующим образом:

cell_range = ws ['A1': 'C2'] # Получить область в пределах A1-C2
 colC = ws ['C'] # Получить столбец C
 col_range = ws ['C: D'] # Получить столбец C-D
 row10 = ws [10] # Получить 10-й столбец
 row_range = ws [5:10] # Получить 5-10 столбец

'''

'''
Вставка / удаление строк / столбцов, перемещение ячеек области

Вставить строку / столбец

Вставьте строку над строкой 7 следующим образом:

ws.insert_rows(7)
 
Вставьте столбец слева от столбца 7 следующим образом:

ws.insert_cols(7)

'''

'''
Стиль заливки

Для получения подробной информации перейдите к стилю заливки

from openpyxl.styles import PatternFill
fill = PatternFill(fill_type=None,
 start_color='FFFFFFFF',
 end_color='FF000000')

'''


'''
сохранить документ

Используйте метод Workbook.save () для сохранения книги, этот метод перезапишет исходный файл без запроса, как показано ниже:

wb = Workbook()
'''






from openpyxl import Workbook, load_workbook
from openpyxl.styles import PatternFill
'''
Открыть существующую таблицу Excel
from openpyxl import Workbook, load_workbook
wb = load_workbook('sample.xlsx')
'''


class Table_adder():
	
	def maker(self, tab_name, datas):

		#Открыть существующую таблицу Excel
		wb = load_workbook('troubles.xlsx')

		'''
		Создать / получить лист
		Используйте метод Workbook.create_sheet () для создания нового листа.
		Первый параметр - это имя листа.
		Если он не заполнен, по умолчанию он будет называться Sheet1 Sheet2 Sheet3;
		второй параметр - это позиция для вставки таблицы Sheet, с 0 в качестве первой позиции,
		если она не заполнена, она будет В конце. следующее:
		'''
		ws = wb.create_sheet (tab_name) # По умолчанию вставляется в конец

		'''
		Операционная ячейка
		Получите ячейку с листа или назначьте ячейку напрямую, как показано ниже:
		'''
		redFill = PatternFill(start_color='FFFF0000',
                   end_color='FFFF0000',
                   fill_type='solid')

		for i, item in enumerate(datas):
			ws['A' + str(i+1)] = item['terminal'] # Присвойте значение 4 ячейке в строке 4 и столбце A
			ws['B' + str(i+1)] = item['error_type'] # Присвойте значение 4 ячейке в строке 4 и столбце A
			cell = ws['A' + str(i+1)] # Получить ячейку в строке 4 и столбце A
			ws['A' + str(i+1)].fill = redFill
			ws['B' + str(i+1)].fill = redFill
		'''
		Стиль заливки
		Для получения подробной информации перейдите к стилю заливки
		'''
		


		'''
		сохранить документ
		Используйте метод Workbook.save () для сохранения книги, этот метод перезапишет исходный файл без запроса, как показано ниже:
		'''
		wb.save('troubles.xlsx')
		

if __name__ == '__main__':
	datas = [{'terminal': 'test1','error_type': 'test2'},{'terminal': 'test3','error_type': 'test4'}]
	table_name = 'test'

	ta = Table_adder()
	ta.maker(table_name, datas)

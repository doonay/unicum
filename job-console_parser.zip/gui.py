from console_errors_finder import get_custom_terminal_error
from console_errors_finder import text_parser
from console_errors_finder import all_errors_finder
from kivy.app import App
from kivy.uix.button import Button
from kivy.uix.textinput import TextInput
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label

class Screen(FloatLayout):

    def morning_check(self):
        #input = self.textinput_widget
        return_list = all_errors_finder()
        if len(return_list) > 0: 
            self.textinput_widget.text = "\n".join(return_list)
        else:
            self.textinput_widget.text = 'Технические неисправности в указанных терминалах отсутствуют'

    def clean(self):
        self.textinput_widget.text = ''

    def parse_table(self):
        input = self.textinput_widget
        arr = text_parser(input.text)
        return_list = get_custom_terminal_error(arr)
        print('back', "\n".join(return_list))
        self.textinput_widget.text = "\n".join(return_list)

class MyApp(App):
    def build(self):
        return Screen()

if __name__ == '__main__':
	MyApp().run()
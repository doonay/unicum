import configparser
import requests
from bs4 import BeautifulSoup
import lxml
from datetime import date
import csv
from lxml import etree




session = requests.Session()
session.headers.update({'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.131 Safari/537.36'})

tokenRequest = session.get('https://umarket.unicum.ru/Home/Login')

parser = etree.HTMLParser()
tree = etree.fromstring(tokenRequest.text, parser)
verificationToken = tree.xpath('//form//input[@name="__RequestVerificationToken"]/@value')[0]

sessionCookies = tokenRequest.cookies

payload = {
    '__RequestVerificationToken': verificationToken,
    'Email': 'd.dunaev@uvenco.ru',
    'Password': 'Go_063223',
    'RememberMe': 'false',
}

#raw = urllib.urlencode(payload)
headers = {
    'Content-Type': 'application/x-www-form-urlencoded',
}
plateRequest = session.post('https://umarket.unicum.ru/Home/Login', data=payload, cookies=sessionCookies, headers=headers)

soup = BeautifulSoup(plateRequest.text, 'lxml')
cards = soup.find_all('tr', style="background-color:red")
data = []
for card in cards:
    temp = {}
    if card.find('a').find_next().get('href').rfind('.msk.umarket.vpn') != -1:
        terminal = card.find('a').find_next().get('href')[19:-16].upper()
        error_type = card.find('td', style="width: 100px").getText()
        temp['terminal'] = terminal
        temp['error_type'] = error_type
        data.append(temp)

for d in data:
    print(d)

current_date_str = str(date.today().strftime("%d%m%y"))

with open(current_date_str + '.csv', 'w') as csvfile:
    fieldnames = ['terminal', 'error_type']
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    for element in data:
        writer.writerow({'terminal': element.get('terminal'), 'error_type': element.get('error_type')})
    
print("Writing complete")

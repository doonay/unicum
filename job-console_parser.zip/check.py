import csv
from datetime import date

current_date_str = str(date.today().strftime("%d%m%y"))

check_list = 'checklist.txt'
check_shopnames = []
with open(check_list, "r") as file:
    for line in file:
        check_shopnames.append(line.strip())

errors_dict = current_date_str + '.csv'
with open(errors_dict) as file:
    reader = csv.DictReader(file)
    for row in reader:
        #print(row.get('terminal'))
        for check in check_shopnames:
            #print(row.get('terminal'), type(row.get('terminal')), check, type(check))
            if row.get('terminal') == check:
                print(row.get('terminal'), row.get('error_type'))

import configparser
import requests
from bs4 import BeautifulSoup
#import lxml
from datetime import date
import csv
from lxml import etree
from xlsxmake import Table_adder



current_date_str = str(date.today().strftime("%d%m%y"))

#принимает строку, возвращает массив точек
def text_parser(string: str):
    print(string.find('\n'))
    print()
    arr = string.split('\n')
    print(arr)
    new_arr = []
    for element in arr:
        #print(element)
        x = element.find('\t')
        print(element[:x])
        new_arr.append(element[:x])
    
    return(new_arr)

def all_errors_finder():



    session = requests.Session()
    session.headers.update({'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.131 Safari/537.36'})

    tokenRequest = session.get('https://umarket.unicum.ru/Home/Login')

    parser = etree.HTMLParser()
    tree = etree.fromstring(tokenRequest.text, parser)
    #print('######################')
    #print(tree.text)
    #print('######################')
    verificationToken = tree.xpath('//form//input[@name="__RequestVerificationToken"]/@value')[0]

    sessionCookies = tokenRequest.cookies

    payload = {
        '__RequestVerificationToken': verificationToken,
        'Email': 'd.dunaev@uvenco.ru',
        'Password': 'Go_063223',
        'RememberMe': 'false',
    }

    #raw = urllib.urlencode(payload)
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
    }
    plateRequest = session.post('https://umarket.unicum.ru/Home/Login', data=payload, cookies=sessionCookies, headers=headers)

    soup = BeautifulSoup(plateRequest.text, 'lxml')


    cards = soup.find_all('tr', style="background-color:red")




    data_list_of_dict = []
    data_str = []
    for card in cards:
        temp = {}
        temp_str = ''
        if card.find('a').find_next().get('href').rfind('.msk.umarket.vpn') != -1:
            terminal = card.find('a').find_next().get('href')[19:-16].upper()
            error_type = card.find('td', style="width: 100px").getText()
            temp['terminal'] = terminal
            temp_str = terminal
            temp_str += '\t'
            temp['error_type'] = error_type
            temp_str += error_type
            data_list_of_dict.append(temp)
            data_str.append(temp_str)

    try:
        ta = Table_adder()
        ta.maker(current_date_str, data_list_of_dict)
    except PermissionError:
        print('Сначала зайкрой эксельку!')

    for i in data_str:
        print(type(i), i)

    with open(current_date_str + '.csv', 'w') as csvfile:
        fieldnames = ['terminal', 'error_type']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames, lineterminator='\r')
        writer.writeheader()
        for element in data_list_of_dict:
            writer.writerow({'terminal': element.get('terminal'), 'error_type': element.get('error_type')})
        
    print("Writing complete")





    return data_str

#получаем массив, возвращаем список
def get_custom_terminal_error(shopnames):
    print('Обрабатываем массив', shopnames)
    return_list = []
    #читаем CSV файл
    with open(current_date_str + '.csv', encoding='utf-8') as File:
        reader = csv.reader(File, delimiter=',', quotechar=',', quoting=csv.QUOTE_MINIMAL)
        for row in reader:
            for shopname in shopnames:
                #print('Запрошен', shopname, 'сверяем с', row[0])
                if shopname == row[0]:
                    return_list.append(str(shopname) + ' - ' + str(row[1]))
                    print('Найдено', str(shopname) + ' - ' + str(row[1]))
                    continue

    print(return_list)
    return(return_list)
            
def main():
    #all_errors_finder()
    #get_custom_terminal_error(['SBERTEH-11', 'RUSAL-VAS-8', 'QIWI']) #тест с ошибкой
    #print(get_custom_terminal_error(['Qiwi', 'SBERTEH-11'])) #тест без ошибки
    #string = 'OZON-42-2	12 908	5 819,8	54,91	0	3 408,5	0\nAST-PRES-15	10 490	4 340	58,63	0	4 340	0\nOZON-55NEW	11 456,5	5 653	50,66	0	3 891	0\nDENTSU-11	9 245,25	3 492,25	62,23	0	3 312,25	180\nOZON-32	13 606,5	7 890	42,01	0	4 281,5	0\nSOVKOMBANK-8	12 034	7 377	38,7	0	7 377	0\nSOK-PRES	12 138	8 035,5	33,8	0	5 703	0\nOZON-54NEW	8 771,5	4 783	45,47	0	3 408,5	0\nDGI-17	12 466	8 691	30,28	0	8 416	275\nAST	7 718	4 239	45,08	0	4 239	0\nDGI-21	8 587	5 134	40,21	0	5 134	0'
    #print(string)
    #print()
    #text_parser(string)
    print(type(all_errors_finder()), all_errors_finder())



if __name__ == '__main__':
    main()
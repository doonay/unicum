# hardpass
Сложный пароль с обходом знака '+'<br/>

![image](https://user-images.githubusercontent.com/18138614/187178759-0a08b581-2148-4e17-851e-bda630be405a.png)
